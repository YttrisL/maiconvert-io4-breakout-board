G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-09-01T14:52:05+02:00*
G04 #@! TF.ProjectId,maiConvert-IO4-hat,6d616943-6f6e-4766-9572-742d494f342d,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-09-01 14:52:05*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
